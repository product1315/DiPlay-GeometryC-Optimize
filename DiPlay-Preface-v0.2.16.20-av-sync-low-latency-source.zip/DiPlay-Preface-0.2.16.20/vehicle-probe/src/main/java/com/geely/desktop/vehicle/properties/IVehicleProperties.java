/*
 * This file is auto-generated.  DO NOT MODIFY.
 * Using: C:\\Users\\di-yu\\AppData\\Local\\TaozaiBuild\\android-sdk\\build-tools\\36.0.0\\aidl.exe -pC:\\Users\\di-yu\\AppData\\Local\\TaozaiBuild\\android-sdk\\platforms\\android-36\\framework.aidl -IC:\\Users\\di-yu\\Documents\\Codex\\2026-08-30\\github-plugin-github-openai-curated-remote\\geely-desktop\\vehicle-api\\src\\main\\aidl -oC:\\Users\\di-yu\\.codex\\tmp\\vehicle-projection-aidl-20261007 C:\\Users\\di-yu\\Documents\\Codex\\2026-08-30\\github-plugin-github-openai-curated-remote\\geely-desktop\\vehicle-api\\src\\main\\aidl\\com\\geely\\desktop\\vehicle\\properties\\IVehicleProperties.aidl
 *
 * DO NOT CHECK THIS FILE INTO A CODE TREE (e.g. git, etc..).
 * ALWAYS GENERATE THIS FILE FROM UPDATED AIDL COMPILER
 * AS A BUILD INTERMEDIATE ONLY. THIS IS NOT SOURCE CODE.
 */
package com.geely.desktop.vehicle.properties;
public interface IVehicleProperties extends android.os.IInterface
{
  /** Default implementation for IVehicleProperties. */
  public static class Default implements com.geely.desktop.vehicle.properties.IVehicleProperties
  {
    @Override public android.os.Bundle getStatus() throws android.os.RemoteException
    {
      return null;
    }
    @Override public java.lang.String[] getModelIds() throws android.os.RemoteException
    {
      return null;
    }
    @Override public java.lang.String getPreset(java.lang.String modelId) throws android.os.RemoteException
    {
      return null;
    }
    @Override public java.lang.String getActiveProfile() throws android.os.RemoteException
    {
      return null;
    }
    @Override public void saveProfile(java.lang.String profileJson) throws android.os.RemoteException
    {
    }
    @Override public android.os.Bundle readProperties(java.lang.String profileJson) throws android.os.RemoteException
    {
      return null;
    }
    @Override public android.os.ParcelFileDescriptor openProbeReport() throws android.os.RemoteException
    {
      return null;
    }
    // carlito | Append-only. A callback Binder owns the lease and releases it on death.
    @Override public android.os.Bundle registerSteeringListener(com.geely.desktop.vehicle.properties.IVehicleSteeringCallback callback, int[] keyCodes, boolean intercept) throws android.os.RemoteException
    {
      return null;
    }
    @Override public void unregisterSteeringListener(com.geely.desktop.vehicle.properties.IVehicleSteeringCallback callback) throws android.os.RemoteException
    {
    }
    @Override public android.os.Bundle getSteeringStatus() throws android.os.RemoteException
    {
      return null;
    }
    // carlito | Append-only instrument lease; entry is permitted only after the client renders a frame.
    @Override public android.os.Bundle updateProjection(android.os.IBinder owner, boolean frameReady) throws android.os.RemoteException
    {
      return null;
    }
    @Override public android.os.Bundle releaseProjection(android.os.IBinder owner) throws android.os.RemoteException
    {
      return null;
    }
    @Override public android.os.Bundle getProjectionStatus() throws android.os.RemoteException
    {
      return null;
    }
    @Override
    public android.os.IBinder asBinder() {
      return null;
    }
  }
  /** Local-side IPC implementation stub class. */
  public static abstract class Stub extends android.os.Binder implements com.geely.desktop.vehicle.properties.IVehicleProperties
  {
    /** Construct the stub and attach it to the interface. */
    @SuppressWarnings("this-escape")
    public Stub()
    {
      this.attachInterface(this, DESCRIPTOR);
    }
    /**
     * Cast an IBinder object into an com.geely.desktop.vehicle.properties.IVehicleProperties interface,
     * generating a proxy if needed.
     */
    public static com.geely.desktop.vehicle.properties.IVehicleProperties asInterface(android.os.IBinder obj)
    {
      if ((obj==null)) {
        return null;
      }
      android.os.IInterface iin = obj.queryLocalInterface(DESCRIPTOR);
      if (((iin!=null)&&(iin instanceof com.geely.desktop.vehicle.properties.IVehicleProperties))) {
        return ((com.geely.desktop.vehicle.properties.IVehicleProperties)iin);
      }
      return new com.geely.desktop.vehicle.properties.IVehicleProperties.Stub.Proxy(obj);
    }
    @Override public android.os.IBinder asBinder()
    {
      return this;
    }
    @Override public boolean onTransact(int code, android.os.Parcel data, android.os.Parcel reply, int flags) throws android.os.RemoteException
    {
      java.lang.String descriptor = DESCRIPTOR;
      if (code >= android.os.IBinder.FIRST_CALL_TRANSACTION && code <= android.os.IBinder.LAST_CALL_TRANSACTION) {
        data.enforceInterface(descriptor);
      }
      if (code == INTERFACE_TRANSACTION) {
        reply.writeString(descriptor);
        return true;
      }
      switch (code)
      {
        case TRANSACTION_getStatus:
        {
          android.os.Bundle _result = this.getStatus();
          reply.writeNoException();
          _Parcel.writeTypedObject(reply, _result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_getModelIds:
        {
          java.lang.String[] _result = this.getModelIds();
          reply.writeNoException();
          reply.writeStringArray(_result);
          break;
        }
        case TRANSACTION_getPreset:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          java.lang.String _result = this.getPreset(_arg0);
          reply.writeNoException();
          reply.writeString(_result);
          break;
        }
        case TRANSACTION_getActiveProfile:
        {
          java.lang.String _result = this.getActiveProfile();
          reply.writeNoException();
          reply.writeString(_result);
          break;
        }
        case TRANSACTION_saveProfile:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          this.saveProfile(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_readProperties:
        {
          java.lang.String _arg0;
          _arg0 = data.readString();
          android.os.Bundle _result = this.readProperties(_arg0);
          reply.writeNoException();
          _Parcel.writeTypedObject(reply, _result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_openProbeReport:
        {
          android.os.ParcelFileDescriptor _result = this.openProbeReport();
          reply.writeNoException();
          _Parcel.writeTypedObject(reply, _result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_registerSteeringListener:
        {
          com.geely.desktop.vehicle.properties.IVehicleSteeringCallback _arg0;
          _arg0 = com.geely.desktop.vehicle.properties.IVehicleSteeringCallback.Stub.asInterface(data.readStrongBinder());
          int[] _arg1;
          _arg1 = data.createIntArray();
          boolean _arg2;
          _arg2 = (0!=data.readInt());
          android.os.Bundle _result = this.registerSteeringListener(_arg0, _arg1, _arg2);
          reply.writeNoException();
          _Parcel.writeTypedObject(reply, _result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_unregisterSteeringListener:
        {
          com.geely.desktop.vehicle.properties.IVehicleSteeringCallback _arg0;
          _arg0 = com.geely.desktop.vehicle.properties.IVehicleSteeringCallback.Stub.asInterface(data.readStrongBinder());
          this.unregisterSteeringListener(_arg0);
          reply.writeNoException();
          break;
        }
        case TRANSACTION_getSteeringStatus:
        {
          android.os.Bundle _result = this.getSteeringStatus();
          reply.writeNoException();
          _Parcel.writeTypedObject(reply, _result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_updateProjection:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          boolean _arg1;
          _arg1 = (0!=data.readInt());
          android.os.Bundle _result = this.updateProjection(_arg0, _arg1);
          reply.writeNoException();
          _Parcel.writeTypedObject(reply, _result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_releaseProjection:
        {
          android.os.IBinder _arg0;
          _arg0 = data.readStrongBinder();
          android.os.Bundle _result = this.releaseProjection(_arg0);
          reply.writeNoException();
          _Parcel.writeTypedObject(reply, _result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        case TRANSACTION_getProjectionStatus:
        {
          android.os.Bundle _result = this.getProjectionStatus();
          reply.writeNoException();
          _Parcel.writeTypedObject(reply, _result, android.os.Parcelable.PARCELABLE_WRITE_RETURN_VALUE);
          break;
        }
        default:
        {
          return super.onTransact(code, data, reply, flags);
        }
      }
      return true;
    }
    private static class Proxy implements com.geely.desktop.vehicle.properties.IVehicleProperties
    {
      private android.os.IBinder mRemote;
      Proxy(android.os.IBinder remote)
      {
        mRemote = remote;
      }
      @Override public android.os.IBinder asBinder()
      {
        return mRemote;
      }
      public java.lang.String getInterfaceDescriptor()
      {
        return DESCRIPTOR;
      }
      @Override public android.os.Bundle getStatus() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.os.Bundle _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getStatus, _data, _reply, 0);
          _reply.readException();
          _result = _Parcel.readTypedObject(_reply, android.os.Bundle.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public java.lang.String[] getModelIds() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String[] _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getModelIds, _data, _reply, 0);
          _reply.readException();
          _result = _reply.createStringArray();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public java.lang.String getPreset(java.lang.String modelId) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(modelId);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getPreset, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readString();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public java.lang.String getActiveProfile() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        java.lang.String _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getActiveProfile, _data, _reply, 0);
          _reply.readException();
          _result = _reply.readString();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public void saveProfile(java.lang.String profileJson) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(profileJson);
          boolean _status = mRemote.transact(Stub.TRANSACTION_saveProfile, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public android.os.Bundle readProperties(java.lang.String profileJson) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.os.Bundle _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeString(profileJson);
          boolean _status = mRemote.transact(Stub.TRANSACTION_readProperties, _data, _reply, 0);
          _reply.readException();
          _result = _Parcel.readTypedObject(_reply, android.os.Bundle.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public android.os.ParcelFileDescriptor openProbeReport() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.os.ParcelFileDescriptor _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_openProbeReport, _data, _reply, 0);
          _reply.readException();
          _result = _Parcel.readTypedObject(_reply, android.os.ParcelFileDescriptor.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // carlito | Append-only. A callback Binder owns the lease and releases it on death.
      @Override public android.os.Bundle registerSteeringListener(com.geely.desktop.vehicle.properties.IVehicleSteeringCallback callback, int[] keyCodes, boolean intercept) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.os.Bundle _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(callback);
          _data.writeIntArray(keyCodes);
          _data.writeInt(((intercept)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_registerSteeringListener, _data, _reply, 0);
          _reply.readException();
          _result = _Parcel.readTypedObject(_reply, android.os.Bundle.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public void unregisterSteeringListener(com.geely.desktop.vehicle.properties.IVehicleSteeringCallback callback) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongInterface(callback);
          boolean _status = mRemote.transact(Stub.TRANSACTION_unregisterSteeringListener, _data, _reply, 0);
          _reply.readException();
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
      }
      @Override public android.os.Bundle getSteeringStatus() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.os.Bundle _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getSteeringStatus, _data, _reply, 0);
          _reply.readException();
          _result = _Parcel.readTypedObject(_reply, android.os.Bundle.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      // carlito | Append-only instrument lease; entry is permitted only after the client renders a frame.
      @Override public android.os.Bundle updateProjection(android.os.IBinder owner, boolean frameReady) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.os.Bundle _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(owner);
          _data.writeInt(((frameReady)?(1):(0)));
          boolean _status = mRemote.transact(Stub.TRANSACTION_updateProjection, _data, _reply, 0);
          _reply.readException();
          _result = _Parcel.readTypedObject(_reply, android.os.Bundle.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public android.os.Bundle releaseProjection(android.os.IBinder owner) throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.os.Bundle _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          _data.writeStrongBinder(owner);
          boolean _status = mRemote.transact(Stub.TRANSACTION_releaseProjection, _data, _reply, 0);
          _reply.readException();
          _result = _Parcel.readTypedObject(_reply, android.os.Bundle.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
      @Override public android.os.Bundle getProjectionStatus() throws android.os.RemoteException
      {
        android.os.Parcel _data = android.os.Parcel.obtain();
        android.os.Parcel _reply = android.os.Parcel.obtain();
        android.os.Bundle _result;
        try {
          _data.writeInterfaceToken(DESCRIPTOR);
          boolean _status = mRemote.transact(Stub.TRANSACTION_getProjectionStatus, _data, _reply, 0);
          _reply.readException();
          _result = _Parcel.readTypedObject(_reply, android.os.Bundle.CREATOR);
        }
        finally {
          _reply.recycle();
          _data.recycle();
        }
        return _result;
      }
    }
    static final int TRANSACTION_getStatus = (android.os.IBinder.FIRST_CALL_TRANSACTION + 0);
    static final int TRANSACTION_getModelIds = (android.os.IBinder.FIRST_CALL_TRANSACTION + 1);
    static final int TRANSACTION_getPreset = (android.os.IBinder.FIRST_CALL_TRANSACTION + 2);
    static final int TRANSACTION_getActiveProfile = (android.os.IBinder.FIRST_CALL_TRANSACTION + 3);
    static final int TRANSACTION_saveProfile = (android.os.IBinder.FIRST_CALL_TRANSACTION + 4);
    static final int TRANSACTION_readProperties = (android.os.IBinder.FIRST_CALL_TRANSACTION + 5);
    static final int TRANSACTION_openProbeReport = (android.os.IBinder.FIRST_CALL_TRANSACTION + 6);
    static final int TRANSACTION_registerSteeringListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 7);
    static final int TRANSACTION_unregisterSteeringListener = (android.os.IBinder.FIRST_CALL_TRANSACTION + 8);
    static final int TRANSACTION_getSteeringStatus = (android.os.IBinder.FIRST_CALL_TRANSACTION + 9);
    static final int TRANSACTION_updateProjection = (android.os.IBinder.FIRST_CALL_TRANSACTION + 10);
    static final int TRANSACTION_releaseProjection = (android.os.IBinder.FIRST_CALL_TRANSACTION + 11);
    static final int TRANSACTION_getProjectionStatus = (android.os.IBinder.FIRST_CALL_TRANSACTION + 12);
  }
  /** @hide */
  public static final java.lang.String DESCRIPTOR = "com.geely.desktop.vehicle.properties.IVehicleProperties";
  public android.os.Bundle getStatus() throws android.os.RemoteException;
  public java.lang.String[] getModelIds() throws android.os.RemoteException;
  public java.lang.String getPreset(java.lang.String modelId) throws android.os.RemoteException;
  public java.lang.String getActiveProfile() throws android.os.RemoteException;
  public void saveProfile(java.lang.String profileJson) throws android.os.RemoteException;
  public android.os.Bundle readProperties(java.lang.String profileJson) throws android.os.RemoteException;
  public android.os.ParcelFileDescriptor openProbeReport() throws android.os.RemoteException;
  // carlito | Append-only. A callback Binder owns the lease and releases it on death.
  public android.os.Bundle registerSteeringListener(com.geely.desktop.vehicle.properties.IVehicleSteeringCallback callback, int[] keyCodes, boolean intercept) throws android.os.RemoteException;
  public void unregisterSteeringListener(com.geely.desktop.vehicle.properties.IVehicleSteeringCallback callback) throws android.os.RemoteException;
  public android.os.Bundle getSteeringStatus() throws android.os.RemoteException;
  // carlito | Append-only instrument lease; entry is permitted only after the client renders a frame.
  public android.os.Bundle updateProjection(android.os.IBinder owner, boolean frameReady) throws android.os.RemoteException;
  public android.os.Bundle releaseProjection(android.os.IBinder owner) throws android.os.RemoteException;
  public android.os.Bundle getProjectionStatus() throws android.os.RemoteException;
  /** @hide */
  static class _Parcel {
    static private <T> T readTypedObject(
        android.os.Parcel parcel,
        android.os.Parcelable.Creator<T> c) {
      if (parcel.readInt() != 0) {
          return c.createFromParcel(parcel);
      } else {
          return null;
      }
    }
    static private <T extends android.os.Parcelable> void writeTypedObject(
        android.os.Parcel parcel, T value, int parcelableFlags) {
      if (value != null) {
        parcel.writeInt(1);
        value.writeToParcel(parcel, parcelableFlags);
      } else {
        parcel.writeInt(0);
      }
    }
  }
}
